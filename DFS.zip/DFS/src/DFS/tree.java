package DFS;

public class tree {

//	Node A = new Node(3);
//    A.setData(1);
//    Node G = new Node(2);
//    G.setData(2);
//    Node I = new Node(1);
//    I.setData(3);
//    Node J = new Node(0);
//    Node H = new Node(0);
//    Node B = new Node(1);
//    Node C= new Node(0);
//    Node F= new Node(2);
//    Node D = new Node(0);
//    Node E = new Node(0);
//    A.getRefchild()[0] = G;
//    A.getRefchild()[1] = B;
//    A.getRefchild()[2] = F;
//    G.getRefchild()[0] = I;
//    G.getRefchild()[1] = H;
//    System.out.println(A.getRefchild()[0].getRefchild()[0].getData());
//    
//    
}
