package DFS;

public class Node {
	
//	
//	private Object data;
//	private Node[] refchild;
//	
//	Node(int no_of_childs){
//		
//		setRefchild(new Node[no_of_childs]);
//	}
//
//	public void setData(Object data) {
//		this.data = data;
//	}
//
//	public Node[] getRefchild() {
//		return refchild;
//	}
//
//	public void setRefchild(Node[] nodes) {
//		this.refchild = nodes;
//	}
//
//	public Object getData() {
//		return data;
//	}
//	

}
