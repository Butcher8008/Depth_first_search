package DFS;

public class MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	        

		

       traverse a = new traverse(3); 
          
        a.setData(1);
        
       traverse b = new traverse(2);
       
       b.setData(2);
       
       traverse c = new traverse(1);
       
       c.setData(1);
       
       traverse J1 = new traverse(0);
       traverse H1 = new traverse(0);
       traverse B1 = new traverse(1);
       traverse C1= new traverse(0);
       traverse F1= new traverse(2);
       traverse D1 = new traverse(0);
       traverse E1 = new traverse(0);
       a.getRefchild()[0] = b;
       a.getRefchild()[1] = B1;
       a.getRefchild()[2] = F1;
       b.getRefchild()[0] = c;
       b.getRefchild()[1] = H1;
  
       
      
        System.out.println("Following is the Depth First Traversal"); 
        a.DFS(0); 

		
		
		

	}

}
